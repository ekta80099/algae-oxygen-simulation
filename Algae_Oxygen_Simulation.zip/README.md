# Algae-Based Oxygen Regeneration Simulation in MATLAB

This beginner-friendly project simulates how algae can regenerate oxygen by consuming CO₂ using basic MATLAB coding.

## 📌 Project Goals
- Simulate oxygen (O₂) and carbon dioxide (CO₂) levels over time
- Visualize algae photosynthesis in a closed-loop system
- Practice basic MATLAB coding and plotting

## 📁 Files
- `algae_oxygen_simulation.m`: Main MATLAB script
- `README.md`: Project overview

## 🧠 Concepts Used
- MATLAB plotting
- Basic differential equations (ODE)
- Algae photosynthesis modeling

## 🚀 How to Run
1. Open MATLAB
2. Run `algae_oxygen_simulation.m`
3. View the O₂ and CO₂ levels plot

---

Made for space life support system enthusiasts 🌱🚀
