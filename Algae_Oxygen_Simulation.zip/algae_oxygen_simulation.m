
% Algae-Based Oxygen Regeneration System Simulation

% Time (in hours)
t = 0:0.1:72;  % Simulate for 3 days

% Initial conditions
CO2 = zeros(size(t));
O2 = zeros(size(t));

% Initial concentrations (in arbitrary units)
CO2(1) = 100;
O2(1) = 10;

% Constants
photosynthesis_rate = 0.5;  % Rate of CO2 consumption and O2 production

% Simulate over time
for i = 2:length(t)
    CO2(i) = CO2(i-1) - photosynthesis_rate * 0.1;
    O2(i) = O2(i-1) + photosynthesis_rate * 0.1;

    if CO2(i) < 0
        CO2(i) = 0;
    end
end

% Plotting
figure;
plot(t, CO2, 'r', 'LineWidth', 2);
hold on;
plot(t, O2, 'g', 'LineWidth', 2);
xlabel('Time (hours)');
ylabel('Concentration');
legend('CO2', 'O2');
title('Algae-Based Oxygen Regeneration Simulation');
grid on;
